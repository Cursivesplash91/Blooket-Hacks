<p align="center">Cheats made by someone who knows more about what they're doing</p>

# Vision Board

- [ ] Auto Play
- [ ] GUI ingame chat for cheaters? (Low chance of this happening)
- [ ] More Racing cheats
- [ ] Change name during game
- [ ] Set players gold/crypto

## Information

<details><summary><h3>Where's Minesraft2?</h3></summary>
Idk
</details>

<details><summary><h3>(script) is not working?</h3></summary>
I won't fix it.
</details>
