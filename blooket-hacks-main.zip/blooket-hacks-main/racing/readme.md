# Racing Cheats

## [Instant Win](instantWin.js)
Instantly Wins the race